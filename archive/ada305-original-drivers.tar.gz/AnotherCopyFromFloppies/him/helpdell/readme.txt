ACS495 Speakers - Audio Management Software 

CONTENTS
========

 1. Minimum Requirements
 2. Installation
 3. About the ACS495 Audio Management Software
 4. ACS495- Audio Management Software Folder
 5. Uninstalling the Audio Management Software
 6. ACS495 Software Description 
 7. ACS495 Speaker Description 
 8. USB Control
 9. Stand Alone Mode


MINIMUM REQUIREMENTS
====================
1. Pentium Processor 100 MHz or higher
2. 16 MB RAM
3. Win95 OSR2.1  
4. Sound card install 
5. USB host hub connector
6. 8 MB disk space


INSTALLATION
============
ACS495 Speakers - speaker management software is preinstalled by Dell. If 
you install the software from CD, use the following instructions.

To install the speaker management software

1. Insert the CD-ROM into your CD drive.

2. Click Start, and select Run.

3. In the Run dialog box, type 'x:setup.exe', where 'x' is your CD drive.

4. Follow the installation instructions. It's best to use the default 
options during the installation.

5. After the installation program finishes, restart the computer. 

The installation program creates a new program folder named 'ACS495 
Speakers' on the Program menu. 

You can now connect the ACS495 USB speakers to your computer and enjoy a 
new generation of interactively controlled speakers.


About ACS495 Audio Management Software
======================================

Altec Lansing's ACS495 speakers use the new USB (Universal Serial Bus) 
architecture, which is a new industry standard external digital serial bus 
connected to the host PC. This new architecture enables full 
bi-directional connectivity between the computer and speakers. This 
connectivity ensures full coherence between the volume levels on the 
speakers' control panel and the Speaker Management Interface on your 
computer's display.

Each time you change the volume settings or  mode on the 
speakers' control panel, the Speaker Management Interface display also 
changes. Similarly, each time you make a change on the Speaker Management 
Interface, the speakers respond accordingly.

The Speaker Management Interface indicates if the speakers are connected 
via a USB cable to the host. The Speaker Management Interface also
displays the speakers' mode of operation: stereo or Dolby Prologic.

You don't need any other USB drivers to use the software. Microsoft's USB 
supplement and the ACS495 Speaker management Software are all you need.


ACS495- Audio Management Software Folder
========================================

This group contains two icons:
1. The 'ReadMe' icon to display this file.
2. The 'ACS495 Speaker Software' icon for running the application. 


UNINSTALL
=========

To uninstall the software, double-click the Add/Remove Programs in the 
Control Panel, select the Install/Uninstall tab, and select ACS495 
Speaker/Speaker Management Interface. The uninstall program removes all 
the files copied to your computer, and updates the system files.



ACS495 Software Description
===========================

Displaying the Speaker Management Interface
===========================================

Use any of the following methods to display the Speaker Management 
Interface:
1.	Adjusting the rotary wheel or pressing a channel selector 
on the right satellite speaker.
2.	Double-clicking on the icon in the tray on the taskbar. 
The icon appears in the tray when your speakers are powered on and 
connected to the computer through a USB cable.
3.	Double-clicking on the USB Speakers Management Interface icon.

You can use a mouse to adjust the sliders, change the interface's 
operating mode, select or program presets, and make selections from menus.

If you display the Speaker Management Interface by adjusting a control on 
the right satellite, the display disappears after three seconds of no 
adjustments. If you display the Interface by clicking on an icon, you can 
hide the display by closing or minimizing its window.


Speaker Management Interface Objects
====================================

The following controls are part of the Speaker Management Interface:

Mute button - toggles mute/unmute.

Master volume slider - controls the overall sound level.

Speaker sliders - changes the volume level of each speaker independently, 
and sets the two surround speakers jointly. The Interface enables and 
disables sliders depending on the current mode.

The following colors on the sliders indicate operation states:
  red - enabled
  gray - disabled
  blue - selected



Toolbar
=======

The following buttons appear on the toolbar.

Mode buttons
* Activate Prologic mode 
* Activate stereo mode

When in Stereo Mode, the following controls are available:
* Toggle mute/unmute
* Master volume slider
  Left speaker volume slider
  Right speaker volume slider
  Subwoofer speaker volume slider

Other sliders are disabled. 

When in Prologic Mode, the following controls are available:

* Toggle mute/unmute

* Master volume slider
  Surround speaker sliders
  Center speaker volume slider
  Subwoofer speaker volume slider
  Right speaker volume slider
  Left speaker volume slider

*ACS495 presets - These presets are permanently set for the following 
sound categories:
 Music
 Games
 Movies

*Programmable presets - You can program these presets with slider 
positions. To program a preset, click on it, set the slider positions for 
each speaker, and click on the Save icon. When you click on a programmed 
preset, the sliders take the positions you last programmed.

* Reset - Resets the speaker system to its default settings.

* Save - Saves the current slider positions for the selected programmable 
preset.

* Help - Accesses online help.



ACS495 Speaker Management Software Menus
========================

The USB Speaker Management Interface has the following menu structure:

File - This menu contains the following option:
     Exit - Exits the application.
View - Shows/hides the following elements on the display:
     Toolbar - When checked, the toolbar appears.
     Status bar - When checked, the status bar appears.
     Popup - When checked, the interface is in popup mode. The interface 
          appears whenever you adjust a control on the right satellite
          speaker.
          The interface will disappear after three seconds of no          adjustments.
          You disable popup mode by deselecting this option. Note: When
          you run full-screen applications, the interface does not appear, even if you adjust a control on the right speaker.
Help - This menu contains the following options:
     Help Topics - Accesses online help.
About  - Provides general information about the ACS495 Speaker Management
 Interface.


The ACS495 Popup Mode
========================

The ACS495 Popup Display is a special feature of the ACS495 Speaker Management Software. When enabled, the interface appears whenever you adjust a control on the right satellite speaker.  The interface disappears after three seconds of no adjustments.

You enable or disable popup mode by toggling Popup in the View menu. When your screen is fully utilized by Windows or DOS games, popup mode is automatically 
disabled. 


ACS495 - Speaker Management Interface Description
=================================================

The ACS495 Speaker Management Interface controls the ACS495 speaker
system, a Dolby surround sound speaker system with a USB control. It consists of two satellite speakers and a subwoofer.

+	The left satellite houses two full-range 3" drivers, one forward for the main left channel and a second left side-firing speaker for the surround sound.

+	The right satellite houses two full-range 3" drivers, one forward for the main right channel and a second right side-firing speaker for the surround sound. The right speaker has three channel selectors, a rotary wheel and LEDs.

+	The subwoofer houses a 61/2" dual voice coil long throw woofer, power supply, audio amplifiers, volume controls and Dolby Prologic decode circuits.

You can control your speakers in the following ways:

+	Pressing a channel selector and turning the rotary wheel on the right 
satellite.

+	Using the ACS495 Speaker Management Interface.

+	Using the Windows mixer driver set to ACS495.
You have more control over your computer's speakers using the Speaker Management Interface. You can make presets, and more accurately make settings for each game or program you use.


The Speaker Control Panel
=========================

General
=======

The following controls are on the right speaker:
	Rotary wheel
	Channel selection buttons:
	Subwoofer channel (leftmost)
	Center channel (center)
	Surround channel (rightmost)

When a channel is active, the LED next to its selection button is on. To toggle muting, simultaneously press the subwoofer and surround channel selection buttons.

LED Indicators: 
	Mute. If on, the speakers are muted; if off, the speakers are unmuted.
	Stereo/Prologic. If amber/yellow, the system is in stereo mode; if
	green, the system is in Prologic mode.

You can use these controls in standalone or Prologic modes.


Rotary Wheel
============

Turning the rotary wheel clockwise increases the level of the selected channel; turning the rotary wheel counterclockwise decreases the level. If no selector is selected, the rotary wheel adjusts the master volume.

Channel Selectors
===============

When you press the subwoofer, center or surround channel selector on the right speaker, the corresponding LED indicator turns on. The Interface appears, and the channel's slider is selected. As you turn the rotary wheel, the system adjusts the selected channel's level, and moves the slider on the screen and status bar. Three seconds after setting the volume, the Interface deselects the active channel selector, the master volume again becomes active in the device and on the Interface, and the LED indicator turns off.

Pressing the button of an active channel deselects that channel.


Mute/Unmute
===========

Simultaneously pressing the subwoofer and surround channel selectors mutes the speaker system. The red mute LED, located on the right speaker, turns on.

If you simultaneously press these selectors again, the system unmutes, and the mute LED turns off. 

You can unmute the system using any of the following methods:
+	Pressing any channel selector on the right satellite.
+	Adjusting the volume through the Interface.
+	Adjusting the volume through the Windows mixer.
+	Turning the rotary wheel.


Stereo/Prologic Modes
=================

If the system is in standalone mode, the you can toggle between stereo and
Prologic modes by pressing the center channel selector for at least two
seconds. In stereo mode, the mode LED, located on the front of the right
speaker, appears amber/yellow; in Prologic mode, the mode LED appears
green. 


Standby Mode
===========

The system automatically enters standby mode if there is no audio signal for more than 10 minutes. In standby mode, the speakers consume low power and all LEDs turn off. 

The speakers return to active mode upon receiving any audio signal or
control input.


USB Cable
========

To control speakers using your PC, you must connect them using the USB cable. This cable has two connectors: a flat rectangular connector for the PC side, and a cubical connector for the speaker side located on the subwoofer rear connector panel.


USB Connection
=============

If you connect the USB cable while the PC is on, the speakers are automatically identified and enumerated by the operating system. The application's icon appears in the tray in the lower right-hand corner of the screen. After enumeration is completed, two-way control is established. The same enumeration process occurs if the USB cable is connected when the computer is turned on, or if the computer is on and you turn on the speakers.


Disconnecting the USB Cable
======================

Disconnecting the USB cable does not affect the speaker's operation and
volume level. When the USB cable is disconnected, the Interface is disabled and the speakers operate in standalone mode.


Standalone Mode
=============

If you disconnect the USB cable, remove the ACS495 program, or turn off the computer, the speakers automatically enter standalone mode.

In Standalone Mode, the ACS495 speakers operate as regular speakers, and there is no communication between them and the computer. You can adjust the speakers using the channel selectors and rotary wheel on the right speaker, but you can't adjust them through the PC. Furthermore, the ACS495 interface does not appear, and its icon doesn't appear in the tray. If you try to run the Interface software in standalone mode, you receive a message that the speakers are not connected.

Standalone mode has the following characteristics:
+	No control of speakers through the PC.
+	No balance control between front left and right speakers. 
+	Depressing the center channel selector for more than two seconds toggles between stereo and Prologic modes.

The other functions are the same as for USB control mode. 

Notes:
Setting the front right and left speaker balance is not possible in standalone mode. To regain control over balance, shut down the speakers and then power them on again.  The speaker balance will reset.

The speakers retain their volume settings after power off and power on. 

When the speakers are powered on, they reset to stereo mode. 


